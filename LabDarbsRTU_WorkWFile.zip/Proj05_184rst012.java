import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

class Student{
	public String surname, name;
	public int mark1, mark2, mark3, mark4, mark5;
	Student(String surname, String name, int mark1, int mark2,
	int mark3, int mark4, int mark5) {
		this.surname = surname;
		this.name = name;
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
		this.mark4 = mark4;
		this.mark5 = mark5;
	}
}

public class Proj05_184rst012 {
		
	public static void main(String[] args) throws IOException {
		String fileName;
		Scanner sc = new Scanner(System.in);
		System.out.print("input file name:");
		fileName=sc.nextLine();
		FileReader fin = new FileReader(fileName);
		BufferedReader scanLines = new BufferedReader(fin);
		System.out.println(scanLines.readLine());
		int recordNum = 1;
		String fromFile;
		while ((fromFile=scanLines.readLine()) != null) {
		recordNum++;
				}
		System.out.println("Number of records in the file: "+recordNum);
		Student [] studentData = new Student[recordNum];
		System.out.println(studentData.length);
		scanLines.close();
		FileReader fin1 = new FileReader(fileName);
		BufferedReader scanLines1 = new BufferedReader(fin1);
		for(int i=0;i<studentData.length;i++)
		studentData [i] =null;
		for (int i=0;i<recordNum;i++)
		{
			fromFile = scanLines1.readLine();
			System.out.println(fromFile);
			String[] forSplit = fromFile.split("\\s");
			String aSurname = forSplit[0];
			String aName = forSplit[1];
			int aMark1 = Integer.parseInt(forSplit[2]);
			int aMark2 = Integer.parseInt(forSplit[3]);
			int aMark3 = Integer.parseInt(forSplit[4]);
			int aMark4 = Integer.parseInt(forSplit[5]);
			int aMark5 = Integer.parseInt(forSplit[6]);
			studentData[i] = new Student(aSurname, aName, aMark1, aMark2, aMark3, aMark4, aMark5);
			
		}
		scanLines1.close();
		System.out.print("output file name:");
		fileName=sc.nextLine();
		FileWriter outputFile = new FileWriter(fileName);
		PrintWriter out = new PrintWriter(outputFile);
		for (int i=0;i<recordNum;i++) {
			int [] marks = new int[5];
			marks[0] = studentData[i].mark1;
			marks[1] = studentData[i].mark2;
			marks[2] = studentData[i].mark3;
			marks[3] = studentData[i].mark4;
			marks[4] = studentData[i].mark5;
			double averageMark=0;
			for (int j=0;j<marks.length;j++) {
				averageMark+=marks[j]/marks.length;
			}
			int countMarks=0;
			for (int j=0;j<marks.length;j++) {
				if (marks[j]<4) {
					countMarks++;
				}
				if (countMarks==3) {
					out.print(studentData[i].surname+" ");
					out.print(studentData[i].name+" ");
					out.println(averageMark);
										break;
				}
			}
			
		}
		
		out.flush();			
		out.close();	
		sc.close();
	}

}
