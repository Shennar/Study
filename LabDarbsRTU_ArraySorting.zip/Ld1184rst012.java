import java.util.Scanner;

public class Ld1184rst012 {
public static void firstMethod(int[] a) {
	boolean flag=true;
	int n=a.length, c;
	while (flag==true) {
		flag=false;
		for (int i=0;i<(n-1);i=i+2) {
			if (a[i]>a[i+1]) {
				c=a[i];a[i]=a[i+1];a[i+1]=c;
				flag=true;
			}
		}
		for (int i=1;i<(n-1);i=i+2) {
			if (a[i]>a[i+1]) {
				c=a[i];a[i]=a[i+1];a[i+1]=c;
				flag=true;
			}
		}
	}
} 

public static void quickSort(int[] a, int left, int right) {
	int med; 
	int b[] = {a[left],a[(int) (left+right)/2],a[right]};
	if (b[0]<b[1]) {
		if (b[1]<b[2]) {
			med=b[1];
		} else { if (b[0]<b[2]) {
			med=b[2];}
		else {med=b[0];}
		}
	} else {
		if (b[0]<b[2]) {
			med=b[0];}
		else {
			if (b[1]<b[2]) {
				med=b[2];
			} else {med=b[1];}
		}
	} 

	int i=left, j=right;
	while (i<=j) {
	while (a[i]<med) {i++;}
	while (a[j]>med) {j--;};
	if (i<=j) {
		int glass=a[i];
		a[i]=a[j];
		a[j]=glass;
		i++; j--;
	}
	if (j>left) {
		quickSort(a, left, j);
	}
	if (right>i) {
		quickSort(a, i, right);
	}
	}
}
	public static void main(String[] args) {
		int count, choice;
		Scanner sc = new Scanner(System.in);
		System.out.println("Vladislavs Kremeneckis IRDBD05 184RST012");
		System.out.print("Input number of elements:");
		count = sc.nextInt();
		int a[] = new int [count];
		System.out.println("Input elements of array ("+count+"):");
		for (int i=0;i<count;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("Choose sorting method:");
		System.out.println("1 - for improved odd-even exchage method.");
		System.out.println("2 - for recursive Hoare method.");
		boolean test=true;
		do {
		System.out.print("Enter your choice:");
		choice=sc.nextInt();
		if (choice == 1 | choice== 2) {test = false;}
		} while (test);
		sc.close();
		if (choice==1) {

			firstMethod(a);
		} else {

			quickSort(a, 0, a.length-1);}
	
		System.out.println("Sorted elements of array.");
		for (int i=0;i<count;i++) {
			System.out.print(a[i]+" ");
		}
	}

}
