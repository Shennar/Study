package doubler;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

public class Doubler extends JFrame implements ActionListener {
	private JList inputList; 
	private	JList outputList;
	private DefaultListModel inputModel = new DefaultListModel();
	private DefaultListModel outputModel = new DefaultListModel();
	private JTextField inputLine = new JTextField();
	public Doubler() throws Exception {
		UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		JFrame mainFrame = new JFrame("BorderLayout");
		JPanel leftPanel = new JPanel();
		JPanel rightPanel = new JPanel();
		JPanel topPanel = new JPanel();
		JPanel downPanel = new JPanel();
		JPanel topButtons = new JPanel();
		JButton addButton = new JButton("Add");
		JButton runButton = new JButton("Run");
		JButton delButton = new JButton("Delete");
		JButton clearButton = new JButton("Clear");
		inputList = new JList(inputModel);
		outputList = new JList(outputModel);
		inputList.setLayoutOrientation(JList.VERTICAL);
		outputList.setLayoutOrientation(JList.VERTICAL);
		topPanel.setBorder(new EmptyBorder(5,5,5,5));
		downPanel.setBorder(new EmptyBorder(5,5,5,5));
		leftPanel.setBorder(new EmptyBorder(5,5,5,5));
		rightPanel.setBorder(new EmptyBorder(5,5,5,5));
		leftPanel.add(new JScrollPane(inputList));
		rightPanel.add(new JScrollPane(outputList));
		mainFrame.add(leftPanel,BorderLayout.WEST );
		mainFrame.add(rightPanel,BorderLayout.EAST );
		topPanel.setLayout(new GridLayout(3,1));
		topPanel.add(new JLabel("Input line:"));
		topButtons.add(addButton);
		topButtons.add(runButton);
		topPanel.add(inputLine);
		topPanel.add(topButtons);
		downPanel.add(delButton);
		downPanel.add(clearButton);
		mainFrame.add(topPanel,BorderLayout.NORTH);
		mainFrame.add(downPanel, BorderLayout.SOUTH);
		addButton.addActionListener(this);
		runButton.addActionListener(this);
		delButton.addActionListener(this);
		clearButton.addActionListener(this);
		addButton.setActionCommand("add");
		runButton.setActionCommand("run");
		delButton.setActionCommand("delete");
		clearButton.setActionCommand("clear");
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainFrame.setSize(560, 350);
		mainFrame.setLocation(500, 200);
		mainFrame.setTitle("184RST012");
		mainFrame.setResizable(false);
		mainFrame.setVisible(true);
		
	}
	public static void main(String[] args) throws Exception {
		
		Doubler win = new Doubler();
		
	}
	@Override
	public void actionPerformed(ActionEvent event) {
		
		if (event.getActionCommand().equals("add")) {
			if (!inputLine.getText().equals("")) {
			inputModel.addElement(inputLine.getText());
			inputLine.setText("");
			}
		}
		
		if (event.getActionCommand().equals("run")) {
			outputModel.clear();
			String givenString="", returnString;
			for (int i = 0;i<inputModel.size();i++) {
				givenString=inputModel.elementAt(i).toString();
				returnString="";
				for (int j=0;j<givenString.length();j++) {
					String charToDouble=Character.toString(givenString.charAt(j));
					returnString = returnString+charToDouble+charToDouble;
					}
				outputModel.addElement(returnString);
			}
		}
		
		if (event.getActionCommand().equals("delete")) {
			List indexRange = inputList.getSelectedValuesList();
				 if ( indexRange.size() != 0) {
				 for (int i=0;i<indexRange.size();i++) {
					 inputModel.removeElement(indexRange.get(i));
				 	}
				 }
			}
					
		if (event.getActionCommand().equals("clear")) {
			outputModel.clear();
		}
	}

}
