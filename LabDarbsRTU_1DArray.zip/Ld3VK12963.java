import java.util.Random;
import java.util.Scanner;

public class Ld3VK12963 {

	public static void main(String[] args) {
		int A[] = new int[20];
		int k, c, i;
		System.out.println("Vladislavs Kremeneckis, p. k. 271171-12963");
		Scanner sc = new Scanner(System.in);
		System.out.println("Please choose data for array:");
		System.out.println("0 - for random integers from -50 to 50;");
		System.out.println("another value - for calculated data.");
		System.out.print("Enter your choise:");
		if (sc.hasNextInt())
			k = sc.nextInt();
		else {
			System.out.println("Non-numeric input. Please enter a number.");
			sc.close();
			return;
		}
		sc.close();
		if (k== 0) {
			Random r = new Random();
			for (i=0; i<20; i++) 
				A[i]= r.nextInt(101)-50;
					}
		else {
			A[0]=1;
			for (i=1;i<20;i++) A[i]=A[i-1]+k;
		}
		System.out.println("A:");	
		i=0;
		while (i<20) {
			System.out.printf("%2d\t", A[i]);
			if (i==9) System.out.println();
			i++;
		}
		c=A[0];
		for (i=0;i<19;i++) 
			A[i]=A[i+1];
		A[19]=c;
		System.out.println("\nA:");
		i=0;
		do {
			System.out.printf("%2d\t", A[i]);
			if (i==9) System.out.println();
			i++;
		}
		while (i<20);
		System.out.println("\nDone.");
	}
}
