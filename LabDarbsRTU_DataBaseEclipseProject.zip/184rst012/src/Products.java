import java.time.LocalDate;

public class Products {
	private String productName, producer;
	private double quantity, price;
	private LocalDate expirationDate;
	public Products(String productName, String producer,
			double quantity, double price, LocalDate expirationDate) {
		this.productName = productName;
		this.producer = producer;
		this.quantity = quantity;
		this.price = price;
		this.expirationDate = expirationDate;
	}
	public Products() {
	}
//	@Override
//	public String toString() {
//		return this.productName+" "+this.producer+" "+this.quantity+" "+
//				this.price+" "+this.expirationDate;
//	}
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProducer() {
		return producer;
	}
	public void setProducer(String producer) {
		this.producer = producer;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(LocalDate expirationDate) {
		this.expirationDate = expirationDate;
	}
}