import java.util.Scanner;
public class Ld5VK12963 {

	public static void main(String[] args) {
		int A[][] = new int [10][10];
		int i, j, k, C=34;
		System.out.println("Vladislavs Kremeneckis, p. k. 271171-12963");
		System.out.print("Choose type of array: 1 for A, 2 for B:");
		Scanner sc = new Scanner((System.in));
		if (sc.hasNextInt())
			k = sc.nextInt();
		else {//Non-integer input
			System.out.println("Incorrect input: only 1 or 2 allowed.");
			sc.close();
			return;
		}
		sc.close();
		if (k==1) {
			for (j=0; j<10; j++)
			    for (i=9-j; i>5-j; i--) 
			         if (i>=0) {
	  		            A[i][j] = C; C--;
			        }
		}
		else if (k==2) {
			for (i=0; i<10;i++)
		         for (j=0;j<10;j++) 
		        	if ((9-i-j)>=0) A[i][j]=9-i-j;	
		} 
		else {
			System.out.println("Incorrect input: only 1 or 2 allowed.");
			return;
		}
		for (i=0; i<10; i++) {
			for (j=0; j<10; j++)
				System.out.print(A[i][j] + "\t");
			System.out.println();
		}
	}
}
