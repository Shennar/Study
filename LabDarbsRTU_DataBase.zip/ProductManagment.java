import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class ProductManagment {
	public final static String FILE_NAME="productdata.txt";
	static Scanner scanConsole = new Scanner(System.in);
	
	public static void readFromFile(List<Products> productList) {
		String readName, readProducer, fromFile;
		double readQuantity, readPrice;
		LocalDate readDate;
		BufferedReader inputScanner = null;
		File dataFile = new File(FILE_NAME);
		try {FileReader inputFile = new FileReader(dataFile);
			inputScanner = new BufferedReader(inputFile);
			while ((fromFile=inputScanner.readLine()) != null) {
				String[] forSplit = fromFile.split("\\s");
				readName=forSplit[0].replace("_", " ");
				readProducer=forSplit[1].replace("_", " ");
				readQuantity = Double.parseDouble(forSplit[2]);
				readPrice = Double.parseDouble(forSplit[3]);
				int readYear=Integer.parseInt(forSplit[4]);
				int readMonth=Integer.parseInt(forSplit[5]);
				int readDay=Integer.parseInt(forSplit[6]);
				readDate = LocalDate.of(readYear,readMonth,readDay); // to check &correct
				productList.add(new Products(readName, readProducer, 
								readQuantity, readPrice, readDate));
				}//while
			inputScanner.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
	public static void showAllRecords(List<Products> listToShow) {
		System.out.printf("%-15s%-15s%10s%8s%13s%n", 
				"Pruduct name","Producer","Quantity",
				"Price","Exp. date");
		for (Products itemShow:listToShow) {
			formattedPrint(itemShow);
		}
	}
	public static void addNewRecords(List<Products> listToAdd) {
//		Scanner fromConsole;
		boolean incorrectInput=true;
		String userAnswer = null;
			do {
				do {
//					fromConsole = new Scanner(System.in);
					System.out.print("Add new record? (y - yes, n - no):");
//					while (fromConsole.hasNextLine()) {
					userAnswer = scanConsole.nextLine();
//					break;
//					}
				if (userAnswer.equals("y")| userAnswer.equals("Y")|
						userAnswer.equals("n")| userAnswer.equals("N")) {
					incorrectInput = false;} else {
						System.out.println("Incorrect input. Please try again.");
					}
				} while (incorrectInput);
				if (userAnswer.equals("y")| userAnswer.equals("Y")) {
					listToAdd.add(makeRecord());
					System.out.println("Record added.");
				}
				
			} while (!(userAnswer.equals("n")| userAnswer.equals("N")));
//		 fromConsole.close();
			
	}
	public static void writeToFile(List<Products> listToShow) {
//		System.out.println("Write to the file.");
		FileWriter outputFile;
		try {
			outputFile = new FileWriter(FILE_NAME);
			PrintWriter out = new PrintWriter(outputFile);
			for (Products itemShow:listToShow) {
				out.print(itemShow.getProductName().replace(" ", "_")+" ");
				out.print(itemShow.getProducer().replace(" ", "_")+" ");
				out.print(itemShow.getQuantity()+" ");
				out.print(itemShow.getPrice()+" ");
				out.println(itemShow.getExpirationDate().format(DateTimeFormatter.ofPattern("uuu MM dd")));
			}
			out.flush();
			out.close();
		} catch (IOException e) {
				e.printStackTrace();
		}
		
	}
	public static void deleteRecord(List<Products> listForDelete) {
		for (int i=0;i<listForDelete.size();i++) {
			Products toDelete = listForDelete.get(i); 
			formattedPrint(toDelete);
			if (i==listForDelete.size()-1) System.out.println("Last element.");
			boolean incorrectInput=true;
			String userAnswer;
			do {System.out.print("Delete this record (y - yes, n - next, s - stop deleting):");
				userAnswer=scanConsole.nextLine();
			if (userAnswer.equals("y")| userAnswer.equals("Y")|
					userAnswer.equals("n")| userAnswer.equals("N")|
					userAnswer.equals("s")| userAnswer.equals("S")) {
				incorrectInput = false;} else {
					System.out.println("Incorrect input. Please try again.");
				}
			} while (incorrectInput);
			if (userAnswer.equals("y")| userAnswer.equals("Y")) {
				listForDelete.remove(toDelete);
				System.out.println("Record deleted.");
			} else if (userAnswer.equals("s")| userAnswer.equals("S")) {
				break;
			}
		} //for
		System.out.println("Exit deleting records.");
	}
	public static void changeRecord(List<Products> listForChange) {
		for (int i=0;i<listForChange.size();i++) {
			Products toChange = listForChange.get(i); 
			formattedPrint(toChange);
			if (i==listForChange.size()-1) System.out.println("Last element.");
			boolean incorrectInput=true;
			String userAnswer;
			do {System.out.print("Change this record (y - yes, n - next, s - stop changing):");
				userAnswer=scanConsole.nextLine();
			if (userAnswer.equals("y")| userAnswer.equals("Y")|
					userAnswer.equals("n")| userAnswer.equals("N")|
					userAnswer.equals("s")| userAnswer.equals("S")) {
				incorrectInput = false;} else {
					System.out.println("Incorrect input. Please try again.");
				}
			} while (incorrectInput);
			if (userAnswer.equals("y")| userAnswer.equals("Y")) {
				listForChange.remove(toChange);
				listForChange.add(makeRecord());
				System.out.println("Record changed.");
			} else if (userAnswer.equals("s")|| userAnswer.equals("S")) {
				break;
			}
		} //for

		System.out.println("Exit changing records.");
	}
	public static Products makeRecord() { 
		String userInput, gotProductName, gotProducer;
		double gotQuantity = 0, gotPrice = 0;
		LocalDate gotDate = null;
		System.out.println("Enter data for record.");
		boolean isDataNotGood = true;
		do {
			System.out.print("Enter product name:");
			gotProductName = scanConsole.nextLine();
			if (gotProductName.isEmpty()) {
				System.out.println("Pruduct name could not be empty. Please try again.");
			} else {
				isDataNotGood = false;
			}
		} while (isDataNotGood);
		isDataNotGood = true;
		do {
			System.out.print("Enter producer name:");
			gotProducer = scanConsole.nextLine();
			if (gotProducer.isEmpty()) {
				System.out.println("Pruducer name could not be empty. Please try again.");
			} else {
				isDataNotGood = false;
			}
		} while (isDataNotGood);
		isDataNotGood = true;
		do {
			System.out.print("Enter quantity:");
			userInput = scanConsole.nextLine();
			try {
				gotQuantity = Double.parseDouble(userInput);
				isDataNotGood = false;
			} catch (NumberFormatException e) {
				System.out.println("Non-numeric input. Please try again.");
			}
		} while (isDataNotGood);
		isDataNotGood = true;
		do {
			System.out.print("Enter price:");
			userInput = scanConsole.nextLine();
			try {
				gotPrice = Double.parseDouble(userInput);
				isDataNotGood = false;
			} catch (NumberFormatException e) {
				System.out.println("Non-numeric input. Please try again.");
			}
		} while (isDataNotGood);
		isDataNotGood = true;
		do {
			System.out.println("Please enter expiration date.");
			System.out.print("Year:");
			userInput=scanConsole.nextLine();
			try {
				int expYear=Integer.parseInt(userInput);
				System.out.print("Month:");
				userInput = scanConsole.nextLine();
				int expMonth = Integer.parseInt(userInput);
				System.out.print("Day:");
				userInput = scanConsole.nextLine();
				int expDay=Integer.parseInt(userInput);
				try {
					gotDate = LocalDate.of(expYear, expMonth, expDay);
					isDataNotGood = false;
				} catch (DateTimeException e) {
					System.out.println("Incorrect date. Please try again.");}
			} catch (NumberFormatException e) {
				System.out.println("Noninteger input. Please try again.");
			}
		} while (isDataNotGood);
		return new Products(gotProductName, gotProducer, gotQuantity,
				gotPrice, gotDate);
	}
		public static void findNotOutdated(List<Products> listToFind) {
			boolean incorrectInput=true;
			LocalDate givenDate = null;
			String userAnswer;
		do {
			System.out.println("Please enter expiration date.");
			System.out.print("Year:");
			userAnswer=scanConsole.nextLine();
			try {
				int expYear=Integer.parseInt(userAnswer);
				System.out.print("Month:");
				userAnswer=scanConsole.nextLine();
				int expMonth=Integer.parseInt(userAnswer);
				System.out.print("Day:");
				userAnswer=scanConsole.nextLine();
				int expDay=Integer.parseInt(userAnswer);
				try {
					givenDate = LocalDate.of(expYear, expMonth, expDay);
					incorrectInput = false;
				} catch (DateTimeException e) {
					System.out.println("Incorrect date. Please try again.");}
			} catch (NumberFormatException e) {
				System.out.println("Noninteger input. Please try again.");
			}
		} while (incorrectInput);
			
		for (Products currentRecord : listToFind ) {
			if (givenDate.isBefore(currentRecord.getExpirationDate())) {
				formattedPrint(currentRecord);
			}
		}
//		fromConsole.close();
	}
	public static void averagePrice(List<Products> listToFind) {
		double averagePrice = 0;
		int numberOfProducts = 0;
//		Scanner fromConsole = new Scanner(System.in);
		System.out.print("Please input producer's name:");
		String userAnswer=scanConsole.nextLine();
		for (Products currentRecord : listToFind) {
			if (currentRecord.getProducer().equals(userAnswer)) {
				averagePrice+=currentRecord.getPrice();
				numberOfProducts++;
			}
		}
		if (numberOfProducts==0) {
			System.out.println("No products of producer "+userAnswer+" found.");
		} else System.out.println("Average price is "+(averagePrice/numberOfProducts));
//		fromConsole.close();
	}
	public static void formattedPrint(Products productToPrint) {
		Products a = productToPrint;
			System.out.printf("%-15s%-15s%10.3f%8.2f%13s%n", 
					a.getProductName(),a.getProducer(),a.getQuantity(),
					a.getPrice(),a.getExpirationDate());
		}
	public static void main(String[] args) throws IOException {
		boolean exitProgram = false;
		List<Products> productList = new LinkedList<Products>(); 
		String menuChoice="";
//		Scanner scanConsole = new Scanner(System.in);
		File dataFile = new File(FILE_NAME);
		if (!dataFile.exists() ) {
			dataFile.createNewFile();
		} else {readFromFile(productList);
				}
		while (!exitProgram) {
		System.out.println("Product data manipulation menu");
		System.out.println("1. View all records.");
		System.out.println("2. Add new record."); 
		System.out.println("3. Delete a record.");
		System.out.println("4. Correct a record."); 
		System.out.println("5. Sort by product name.");
		System.out.println("6. Sort by product price.");
		System.out.println("7. Find non-outdated products");
		System.out.println("8. Calculate average price for a producer.");
		System.out.println("0. Exit program.");
		System.out.print("Choose Your action:");
		menuChoice = scanConsole.nextLine();
			switch (menuChoice) {
			case "1": if (productList.size()==0) {
				System.out.println("File is empty. Add records first.");
			} else showAllRecords(productList);
				break;
			case "2": addNewRecords(productList);
				writeToFile(productList);
			break;
			case "3": 
				if (productList.size()==0) {
					System.out.println("File is empty. Add records first.");
				} else deleteRecord(productList);
				break;
			case "4": 
				if (productList.size()==0) {
					System.out.println("File is empty. Add records first.");
				} else {
					changeRecord(productList);
							}
				break;
			case "5": 
				if (productList.size()==0) {
				System.out.println("File is empty. Add records first.");
			} else {
				Collections.sort(productList, new Comparator<Products>() {
	
				      @Override
				      public int compare(Products o1, Products o2) {
				          return o1.getProductName().compareTo(o2.getProductName());
				      }
				  } );
			}
				break;
			case "6": 
				if (productList.size()==0) {
					System.out.println("File is empty. Add records first.");
				} else {
					Collections.sort(productList, new Comparator<Products>() {
	
					      @Override
					      public int compare(Products o1,Products o2){  
					    	  Products s1 = (Products) o1;  
					    	  Products s2 = (Products) o2;  
					    	    
					    	  if(s1.getPrice() == s2.getPrice() ) return 0;  
					    	  else if(s1.getPrice() >s2.getPrice() ) return 1;  
					    	  else return -1;  
					    	  }  
					  } );
				}
				break;
			case "7": 
				if (productList.size()==0) {
					System.out.println("File is empty. Add records first.");
				} else {
					findNotOutdated(productList);
				}
				break;
			case "8": 
				if (productList.size()==0) {
					System.out.println("File is empty. Add records first.");
				} else averagePrice(productList);
				break;
			case "0": System.out.println("Thank you. Good bye.");
				writeToFile(productList);
				exitProgram=true;
				break;
			default: System.out.println("Incorrect input data. Please try again.");
			}
		}// while
		scanConsole.close();
	}//main
}//class0
