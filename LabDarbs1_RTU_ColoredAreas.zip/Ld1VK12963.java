import java.util.Scanner;
public class Ld1VK12963 {
public static void main (String[] args){
Scanner sc = new Scanner(System.in);
		float x=0, y=0;
		System.out.println("Vladislavs Kremeneckis p. k. -12963");
		System.out.print("x=");
		if (sc.hasNextFloat())
			x = sc.nextFloat();
		else {
			System.out.println("Error: non-numerical input. Please try again.");
			sc.close();
			return;
		}
		System.out.print("y=");
		if (sc.hasNextFloat())
			y = sc.nextFloat();
		else {
			System.out.println("Error: non-numerical input. Please try again.");
			sc.close();
			return;
		}
		sc.close();
		if ((x>=1 && x<=6 && y>=4 && y<=(x+3)) ||
		(x>=6 && x<=7 && y>=11 && y<=(x+5)) ||
		(x>=7 && x<=8 && y>=11 && y<=(-x+19)) ||
		(x>=8 && x<=13 && y>=4 && y<=(17-x)))
		System.out.println("Color at "+x+" and "+y+" is blue.");
		else
			if ((y>=8 && ((x-3.5)*(x-3.5)+(y-8)*(y-8))<= 0.5*0.5) ||
			(y>=8 && ((x-10.5)*(x-10.5)+(y-8)*(y-8))<= 0.5*0.5))
		System.out.println("Color at "+x+" and "+y+" is green.");
		else
			if ( (x>=3 && x<=4 && y>(x+3) && y<8) ||
			(x>=6 && x<=8 && y>=3 && y<4) ||
			(x>6 && x<8 && y>=4 && y<9) ||
			(x>=6 && x<=8 && y>=9 && y<11) ||
			(x>=10 && x<=11 && y>(-x+17) && y<8))
		System.out.println("Color at "+x+" and "+y+" is red.");
		else
		System.out.println("Color at "+x+" and "+y+" is white.");
    }	
}
