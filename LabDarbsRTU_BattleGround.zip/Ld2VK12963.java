import java.util.Scanner;
public class Ld2VK12963{
public static void main (String[] args){
Scanner sc = new Scanner(System.in);
		double x=0, y=0, t=0, dt=0.05, ang=0, v0=12, g=8.88;
		System.out.println("Vladislavs Kremeneckis, p. k. 271171-12963");
		System.out.print("Please input shooting angle in degrees: ");
		if (sc.hasNextFloat())
			ang = 3.14*sc.nextFloat()/180;
		else {
			System.out.println("Error: non-numerical input. Please try again.");
			sc.close();
			return;
		}
		sc.close();
	System.out.println("Starting position: x="+x+", y="+y);
	System.out.println("t  \t  x \t  y");
	do {t=t+dt; x=v0*t*Math.cos(ang); y=v0*t*Math.sin(ang)-g*t*t/2;
	System.out.printf("%3.2f\t%7.3f\t%7.3f\n", t, x, y);}
	while ((y>0 && x<=11)||(y>-7 && x>11 && x<=17)||
			(y>-2 && x>17 && x<=20)||(y>-7 && x>20));
	if (x>=17 && x<=20 && y>=-7 && y<=-2)  
		System.out.println("The target was destroyed");
	else 	System.out.println("Shot off the target");
}
}